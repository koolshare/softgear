#！ /bin/sh

rm -rf /koolshare/adm/*.log