#!/bin/sh


rm -rf /koolshare/adm
rm -rf /init.d/S60adm.sh
rm -rf /scripts/adm_*.sh
rm -rf /webs/Module_adm.asp

